
public class Main {

    public static void main(String[] args) {

        Student std1 = new Student("Jonas", "Summermatter", 16);
        Student std2 = new Student("Peter", "Bregy", 19);
        Student std3 = new Student("Ullrich", "Vondenblatten", 22);

        std1.info();
        std2.info();
        std3.info();

    }

}
